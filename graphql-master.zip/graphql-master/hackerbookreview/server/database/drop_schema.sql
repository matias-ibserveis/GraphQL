begin;

drop schema if exists hb cascade;

commit;