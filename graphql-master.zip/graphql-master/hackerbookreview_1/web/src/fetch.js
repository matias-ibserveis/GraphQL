// TODO: add custom GraphQL client "library"
